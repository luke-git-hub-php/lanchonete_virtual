<html>
<meta charset = "utf-8">
<head>
	<title></title>
</head>

<hr class = "barra" color = "#c4870f"><body><div id = "site">Lanche Rápido</div>
<hr class = "barra2" color = "#ffa500">
<img src="logo2.png" id = "x" width= "130px" height = "170px">
<form name = "form" id = "form_input" method = "post" action = "">
	<input type = "text" name = "pesquisa" id = "pesquisa">
	<input type = "submit" name = "nome" id = "nome" placeholder = "Login">
	<input id="search" placeholder="Pesquisa" />
</form>
<div id="menu">
    <ul>
        <li><a href="#">Início</a></li>
            <li><a href="#">Cardápio</a></li>
                <li><a href="#">Contato</a></li>
            <li><a href="#">Entregas</a></li>
    </ul>
</div>



<style type="text/css">
#site{
	margin-top:-100px;
	margin-left: 150px;
	font-size: 40px;
}
#x{
	margin-left: 10px;
	margin-top: -213px;
}

#pesquisa{
	border-radius: 10px;
	margin-left: 900px;
	margin-top:-46px;
}
#nome{
	border-radius: 20px;
	margin-left:1075px;
	margin-top:-43px;
}
.barra2{
	margin-top: 35px;
	height: 50px;
}
.barra{
	height: 145px;
}
.rodape{
	margin-top: 870px; 
	height: 100px;
}
#menu{
	position: relative;
	margin-top: -104px;
}

#menu ul{
	position:absolute;
	padding:3px;
	list-style:none;
	text-align: center;
	font-size: 25px;
}

#menu ul li{display: inline;}

#menu ul li a{
	padding: 10px 20px;
	display: inline-block;
	color: black;
	text-decoration: none;
}

#menu ul li a:hover{
	background-color:#D6D6D6;
}
#footer{    
    background: #c4870f;
    position: relative; 
    bottom: 0; 
    margin-top: 1000px;
    height: 60px;
}
#textorod{
	margin-top: 1000px;
}
</style>
	
</body>
</html>