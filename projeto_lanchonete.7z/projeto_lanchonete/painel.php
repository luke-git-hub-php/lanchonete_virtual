<?php include ('header_index.php');?>
<br><br><br>
<br><br><br>
<br><br><br>
<?php
$conexao=mysqli_connect("localhost","root","","cadastro_restrito")or die(mysqli_error());
?>
<?php
   session_start();
   if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
         header("location:login_area_restrita.php");
         exit;          
   }else{
      	echo "<center>Você está logado!</center>";
   }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Painel</title>
</head>
<body>
<br>
<center><a href="logout_area_restrita.php">
Sair
</a></center>
<?php include ('rodape_index.php');?>
</body>
</html>