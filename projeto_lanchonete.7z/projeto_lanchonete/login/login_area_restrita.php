<!DOCTYPE html>
<html>
<head>
	<title>Aréa Restrita</title>
	</head>
<body>
<?php include ('../header_index.php');?>
<div>
<form name="loginform" method="POST" action="autenticado_usuario.php">
<div>
	Email:<input type="text" name="email" /><br /><br />
	Senha:<input type="password" name="senha" /><br /><br />
	 <input type="submit" value="ENTRAR" /><br /><br />
</div>
	
</form>
</div>
</body>
</html>