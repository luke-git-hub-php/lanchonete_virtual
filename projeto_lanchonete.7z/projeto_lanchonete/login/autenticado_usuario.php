<?php
$conexao=mysqli_connect("localhost","root","","cadastro_restrito")or die(mysqli_error());
?>
<html>
<head>
	<title>Autenticando usuário</title>
	<script type="text/javascript">
	    function loginsuccessfully(){
	    	setTimeout("window.location='painel.php'",5000);
	    }
	   function loginfailed() {
            setTimeout("window.location='login_area_restrita.php'",5000);
	   }
	</script>
</head>
<body>
<?php
$email=$_POST['email'];
$senha=$_POST['senha'];
$sql=mysqli_query($conexao,"SELECT * FROM usuarios WHERE email='$email' and senha='$senha'")or die(mysqli_error());
$linha=mysqli_num_rows($sql);
if($linha > 0){
  session_start();
  $_SESSION['email']=$_POST['email'];
  $_SESSION['senha']=$_POST['senha'];
  echo "<center>Você foi autenticado com sucesso! Aguarde um instante.</center>";
  echo "<script>loginsuccessfully()</script>";
}else{
	echo "<center>Nome do usuário ou senha inválidos! Aguade um instante para tentar novamente.</center>";
	echo "<script>loginfailed()</script>";
}
?>
</body>
</html>