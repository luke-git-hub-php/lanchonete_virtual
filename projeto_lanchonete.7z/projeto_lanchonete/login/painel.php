<?php
$conexao=mysqli_connect("localhost","root","","cadastro_restrito")or die(mysqli_error());
?>
<?php
   session_start();
   if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
         header("location:login_area_restrita.php");
         exit;          
   }else{
      	echo "<center>Você está logado!</center>";
   }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Painel</title>
</head>
<body>

</body>
</html>