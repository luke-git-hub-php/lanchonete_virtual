<div id="footer">         <center><br>Copyright © 2016 | Lanchonete lanche
rápido</center>     </div>