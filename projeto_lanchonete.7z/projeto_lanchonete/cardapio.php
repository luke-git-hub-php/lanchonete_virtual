<html>
<head>
	<title>CARDÁPIO</title>
	
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
		<link rel="stylesheet" type="text/css" href="css_cardapio/cardapio_css.css">

	</head>
<body>
<script>
</script>
<?php include('header_index.php');?>

<h1 id="h1">Cardápio</h1>;
<div id="div">
<span class="imagem"><img src="imagens/sanduiche-em-bh-imagem-destaque.jpg" alt="sanduiche"></span>
</div>

<script>
</script>
<?php include('rodape_index.php');?>
</body>
</html>