<html>
<head>
	<title>index</title>

</head>
<body>
<?php include('header_index.php');?>
<?php include('rodape_index.php');?>
</body>
</html>